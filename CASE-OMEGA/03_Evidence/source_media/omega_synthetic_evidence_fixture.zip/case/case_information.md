# Case Information – OMEGA-2026-001

| Field | Value |
|---|---|
| Case ID | OMEGA-2026-001 |
| Case title | Case Omega – Simulated Ransomware Incident at Omega Multispeciality Hospital |
| Organization | Omega Multispeciality Hospital (fictional) |
| Scenario date | 17 November 2026 |
| Initial notification | 09:00 IST (UTC+05:30) |
| Investigation type | Academic digital forensic simulation |
| Lead examiner | Student investigator – replace with your details |
| Evidence status | Synthetic artifacts generated for this project |

## Fictional environment
- `OMEGA-FS01`: fictional file server
- `OMEGA-WS01`: fictional employee workstation
- `OMEGA-FW01`: fictional firewall/router
- `OMEGA-SW01`: fictional managed switch
- `OMEGA-DC01`: fictional authentication/log server

All names, addresses, users, events, files, and logs are invented. No actual hospital or patient data is represented.

## Investigative questions
1. What sequence of events is represented in the supplied synthetic logs?
2. Which host and account activity appears unusual?
3. What file changes are attributable to the harmless simulator?
4. Can the supplied evidence artifacts be hashed and tracked?
5. What can and cannot be concluded from this simulated dataset?
